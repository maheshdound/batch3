package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Main {
  public static void main(String[] args) {
	   
	  SessionFactory sf=HibernateUtil.getSessionFactory();
	  Session session=sf.openSession();
	  
	  Employee emp=new Employee();
	  emp.setEid(102);
	  emp.setEname("dound");
	  emp.setAddress("manchar");
	  
	  //session.save(emp);
	  //session.saveOrUpdate(emp);
	  //session.saveOrUpdate(emp);
	 // session.persist(emp);
	  //session.delete(emp);
   
	  session.beginTransaction().commit();
	  System.out.println("employee added");
	  
	  
	  
}
}
