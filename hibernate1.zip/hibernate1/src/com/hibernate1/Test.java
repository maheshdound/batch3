package com.hibernate1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Test {
     public static void main(String[] args) {
		
    	 SessionFactory sf=HibernateUtil.getSessionFactory();
    	 Session session=sf.openSession();
    	 
    	 Student st=new Student();
    	 st.setSid(102);
    	 st.setSname("mahesh");
    	 st.setSaddress("pune");
    	 
    	 session.save(st);
    	 session.beginTransaction().commit();
    	 System.out.println("student added");
	}
}
