package com.list;

import java.util.ArrayList;
import java.util.List;

public class ArrayListExample1 {

	public static void main(String[] args) {
		
		List a1 = new ArrayList();
		a1.add(20);
		a1.add(40);
		a1.add(60);
		a1.add("mahesh");
		a1.add(null);
		
		System.out.println(a1);
		System.out.println(a1.size());
		System.out.println(a1.get(1));
		System.out.println(a1.remove(1));
		System.out.println(a1);
		System.out.println(a1.isEmpty());
		System.out.println(a1.contains(60));
	}
}
