package com.list;

import java.util.ArrayList;
import java.util.List;

public class ArrayListExample2 {

	public static void main(String[] args) {
		
		List al = new ArrayList();
		
		al.add(10);
		al.add(20);
		al.add(30);
		al.add("mahesh");
		al.add(null);
		al.add(10);
		
		//System.out.println(al);
		//System.out.println(al.get(0));
		//System.out.println(al.isEmpty());
		//System.out.println(al.contains(30));
		//System.out.println(al.remove(0));
		//System.out.println(al);
		System.out.println(al.removeAll(al));
		System.out.println(al);
		System.out.println(al.isEmpty());
		
	}
}
