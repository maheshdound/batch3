package twolevelcache;

import org.hibernate.Cache;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Controller {
	public static void main(String[] args) {

		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		Session session1 = sf.openSession();
		Employee em = new Employee();
		// em.setEname("datta");
		// em.setEaddress("mumbai");

		// session.save(em);

		Employee employee = session.get(Employee.class, 1);
		Cache cache = sf.getCache();
		cache.evict(Employee.class);
		Employee employee2 = session.get(Employee.class, 1);
		Cache cache1 = sf.getCache();
		cache1.evict(Employee.class);
		Employee employee3 = session1.get(Employee.class, 1);
		// cache.evictAll();
		Employee employee4 = session1.get(Employee.class, 2);
		System.out.println(employee);
		System.out.println(employee2);
		System.out.println(employee3);
		System.out.println(employee4);

		// Cache cache=sf.getCache();
		// cache.evict(Employee.class);

		session.beginTransaction().commit();
		System.out.println("employee added");

	}
}