package com.catchemethod;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Controller {
     public static void main(String[] args) {
		
	
	SessionFactory sf=HibernateUtil.getFactory();
	Session session=sf.openSession();
	
	Student st =new Student();
	st.setSid(103);
	st.setSname("anvi");
	st.setSaddress("pune");
	
	//session.save(st);
	//session.clear();
	Student std=session.get(Student.class, 101);
	System.out.println(std);
	//session.evict(std);
	session.clear();
	Student std1=session.get(Student.class, 101);
	System.out.println(std1);
	
	Student std2=session.get(Student.class, 102);
	System.out.println(std1);
	
	session.evict(std);
	session.beginTransaction().commit();
	
     }
}
