package com.hibernatehql;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
public class Controller {
	public static void getAllEmployee(SessionFactory sf) {
		
		Session s=sf.openSession();
		Query query=s.createQuery("from Employee");
		List<Employee> employee=query.getResultList();
		for(Employee e:employee) {
			
			System.out.println(e);
		}
		
	}
	
	public static void getMaxSalary(SessionFactory sf) {
		
		Session s=sf.openSession();
		Query query=s.createQuery("select Max (esalary) from Employee");
		Object obj=query.getSingleResult();
		System.out.println(obj);
	}
	public static void getSalaryAsceDetail(SessionFactory sf) {
		Session s=sf.openSession();
		Query query=s.createQuery("from Employee e ORDER BY e.esalary ASC");
               List<Employee> emp=query.getResultList();	
	          for(Employee e:emp) {
	        	  System.out.println(e);
	          }
	}
	
	public static void getSecondMaxSalary(SessionFactory sf) {
		Session s=sf.openSession();
		Query query=s.createQuery("from Employee e ORDER BY e.esalary DESC");
		query.setFirstResult(1);
		query.setMaxResults(1);
		Object obj=query.uniqueResult();
		//Object obj=query.getSingleResult();
		System.out.println(obj);
	}
	public static void getThirdMaximumSalary(SessionFactory sf) {
		Session s=sf.openSession();
		Query query=s.createQuery("from Employee e ORDER BY e.esalary DESC");
		query.setFirstResult(1);
		query.setFirstResult(2);
		query.setMaxResults(1);
		Object obj=query.uniqueResult();
		System.out.println("third max salary  :"+ obj);
		
	}
	public static void getNameStartWithM(SessionFactory sf) {
		
		Session s=sf.openSession();
		Query query=s.createQuery("from Employee where ename like 'm%'");
	     List<Employee> e=query.getResultList();
	for(Employee e1:e) {
		System.out.println(e1);
	}
	
	}
	public static void getMinSalary(SessionFactory sf) {
		Session s=sf.openSession();
		Query query=s.createQuery("select Min (esalary) from Employee");
		double d=(double)query.getSingleResult();
		System.out.println(d);
		
	}
	public static void allSalaryDetails(SessionFactory sf) {
		
		Session s=sf.openSession();
            Query<Employee> query=s.createQuery("select esalary(*) from Employee");	
            List<Employee> emp =query.getResultList();	
	       for(Employee e:emp) {
	    	   System.out.println(e);
	       }
	}
	
	public static void getAvarageSalary(SessionFactory sf) {
		Session s=sf.openSession();
		Query query=s.createQuery("select AVG (esalary) from Employee");
		Object obj=query.getSingleResult();
		System.out.println("avarage salary of employee  :"+ obj);
	}
	public static void getNumberOfEmployee(SessionFactory sf) {
		Session s=sf.openSession();
		Query query=s.createQuery("select count(ename) from Employee");
		Object obj=query.getSingleResult();
		System.out.println("number of employee :"+ obj);
		
		
	}
	
	public static void getCountOfSalaries(SessionFactory sf) {

		Session s = sf.openSession();
		Query query = s.createQuery("select count(esalary) from Employee");
		Long count = (Long) query.getSingleResult();
		System.out.println(count);

	}
	
	public static void getSumOfSalary(SessionFactory sf) {
		Session s=sf.openSession();
		Query query=s.createQuery("select SUM (esalary) from Employee");
		Object obj=query.getSingleResult();
		System.out.println("sum of salary  :"+ obj);
		
	}
	
	public static void getNameEndWith(SessionFactory sf) {
		Session s=sf.openSession();
		Query query=s.createQuery("from Employee where ename like '%h'");
		List<Employee> employee=query.getResultList();
		for(Employee e:employee) {
			System.out.println("names end with h");
		System.out.println(e);
	}
	}
	public static void getNameMidWith(SessionFactory sf) {
		Session s=sf.openSession();
		Query query=s.createQuery("from Employee where ename like '%k%'");
		List<Employee> list=query.getResultList();
		for(Employee e:list) {
			System.out.println(e);
		}
	}
	public static void getSalaryDescending(SessionFactory sf) {
		Session s=sf.openSession();
		Query query=s.createQuery("from Employee e ORDER BY e.esalary DESC");
		List<Employee> emp=query.getResultList();
		for(Employee e:emp) {
			
			System.out.println(e);
		}
	}
     public static void main(String[] args) {
		
    	 SessionFactory sf =HibernateUtil.getSessionFactory();
   	// Session session =sf.openSession();
//    	 
    	
    	// getAllEmployee(sf);
    	// getMaxSalary(sf);
    	// getNameStartWithM(sf);
    	 //getMinSalary(sf);
    	// allSalaryDetails(sf);
    	// getAvarageSalary(sf);
    	// getNumberOfEmployee(sf);
    	// getCountOfSalaries(sf);
    	 //getSumOfSalary(sf);
    	 //getNameEndWith(sf);
    	// getNameMidWith(sf);
    	// getSecondMaxSalary(sf);
    	 getThirdMaximumSalary(sf);
    	 //getSalaryAsceDetail(sf);
    	// getSalaryDescending(sf);
    	 
    	 
    	 
//    	 Employee emp=new Employee();
//    	 emp.setEname("tanvi");
//    	 emp.setEaddress("nashik");
//    	 emp.setEsalary(62000);
//    	 
//    	 session.save(emp);
//    	 
//    	 
//    	 session.beginTransaction().commit();
	}
}
